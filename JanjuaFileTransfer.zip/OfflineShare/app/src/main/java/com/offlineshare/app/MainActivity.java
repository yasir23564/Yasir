package com.offlineshare.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Offline Share: bina internet ke ek phone se doosre phone par
 * files, photos, videos, audio aur apps (APK) bhejne wali app.
 * Google Nearby Connections (Bluetooth + Wi-Fi) istemal karti hai.
 */
public class MainActivity extends Activity {

    private static final String SERVICE_ID = "com.offlineshare.app";
    private static final int REQ_PERMS = 1;
    private static final int REQ_PICK = 2;

    private static final int ACTION_NONE = 0;
    private static final int ACTION_SEND = 1;
    private static final int ACTION_RECEIVE = 2;

    private ConnectionsClient client;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private String endpointId = null;
    private boolean connected = false;
    private int pendingAction = ACTION_NONE;

    // Discovery list (sender side)
    private final List<String> foundIds = new ArrayList<>();
    private final List<String> foundNames = new ArrayList<>();
    private ArrayAdapter<String> deviceAdapter;

    // Receive state
    private final Map<Long, Payload> filePayloads = new HashMap<>();
    private final Map<Long, String> incomingNames = new HashMap<>();
    private final Set<Long> finished = new HashSet<>();
    private final Set<Long> saved = new HashSet<>();

    // Send state
    private final Map<Long, String> outgoingNames = new HashMap<>();

    // Views
    private TextView statusView;
    private TextView logView;
    private ScrollView logScroll;
    private ListView deviceList;
    private LinearLayout sendPanel;
    private LinearLayout roleRow;
    private Button disconnectBtn;
    private ProgressBar progressBar;
    private TextView progressLabel;

    // ---------------------------------------------------------------- UI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        client = Nearby.getConnectionsClient(this);
        buildUi();
        setStatus("Shuru karne ke liye Send ya Receive dabayein.");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(color);
        b.setAllCaps(false);
        b.setTextSize(16);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));
        root.setBackgroundColor(Color.parseColor("#F5F7FA"));

        TextView title = new TextView(this);
        title.setText("Janjua File Transfer");
        title.setTextSize(26);
        title.setTextColor(Color.parseColor("#1565C0"));
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Bina internet files, video, audio aur apps bhejein");
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(12));
        root.addView(sub);

        statusView = new TextView(this);
        statusView.setTextSize(15);
        statusView.setTextColor(Color.parseColor("#212121"));
        statusView.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(statusView);

        // Role buttons
        roleRow = new LinearLayout(this);
        roleRow.setOrientation(LinearLayout.HORIZONTAL);
        Button sendBtn = makeButton("Send (Bhejein)", Color.parseColor("#1565C0"));
        Button recvBtn = makeButton("Receive (Wasool)", Color.parseColor("#2E7D32"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        roleRow.addView(sendBtn, lp);
        roleRow.addView(recvBtn, lp);
        root.addView(roleRow);

        sendBtn.setOnClickListener(v -> requestAndRun(ACTION_SEND));
        recvBtn.setOnClickListener(v -> requestAndRun(ACTION_RECEIVE));

        // Nearby devices list
        deviceList = new ListView(this);
        deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, foundNames);
        deviceList.setAdapter(deviceAdapter);
        deviceList.setVisibility(View.GONE);
        deviceList.setOnItemClickListener((parent, view, position, id) -> {
            String target = foundIds.get(position);
            setStatus("Connect ho raha hai: " + foundNames.get(position) + " ...");
            client.requestConnection(Build.MODEL, target, connectionCallback)
                    .addOnFailureListener(e -> setStatus("Connection nahi hua: " + e.getMessage()));
        });
        root.addView(deviceList, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(180)));

        // Send panel (connect hone ke baad)
        sendPanel = new LinearLayout(this);
        sendPanel.setOrientation(LinearLayout.HORIZONTAL);
        Button filesBtn = makeButton("Files / Photos / Videos", Color.parseColor("#1565C0"));
        Button appsBtn = makeButton("Apps", Color.parseColor("#EF6C00"));
        sendPanel.addView(filesBtn, lp);
        sendPanel.addView(appsBtn, lp);
        sendPanel.setVisibility(View.GONE);
        root.addView(sendPanel);

        filesBtn.setOnClickListener(v -> pickFiles());
        appsBtn.setOnClickListener(v -> pickApps());

        progressLabel = new TextView(this);
        progressLabel.setTextSize(13);
        progressLabel.setPadding(dp(8), dp(8), dp(8), 0);
        root.addView(progressLabel);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(1000);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar);

        disconnectBtn = makeButton("Band karein / Disconnect", Color.parseColor("#C62828"));
        disconnectBtn.setVisibility(View.GONE);
        disconnectBtn.setOnClickListener(v -> resetAll("Connection band kar diya."));
        root.addView(disconnectBtn);

        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(13);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        logScroll.addView(logView);
        root.addView(logScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void setStatus(String s) {
        runOnUiThread(() -> statusView.setText(s));
    }

    private void log(String s) {
        runOnUiThread(() -> {
            logView.append(s + "\n");
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    // ------------------------------------------------------- Permissions

    private List<String> neededPermissions() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
            p.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (Build.VERSION.SDK_INT <= 31) {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        return p;
    }

    private void requestAndRun(int action) {
        List<String> missing = new ArrayList<>();
        for (String perm : neededPermissions()) {
            if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }
        if (missing.isEmpty()) {
            runAction(action);
        } else {
            pendingAction = action;
            requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERMS) return;
        boolean ok = results.length > 0;
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        }
        if (ok && pendingAction != ACTION_NONE) {
            int a = pendingAction;
            pendingAction = ACTION_NONE;
            runAction(a);
        } else {
            setStatus("Permissions chahiye. Settings mein Nearby/Bluetooth/Location ki ijazat dein.");
        }
    }

    private void runAction(int action) {
        lastRole = action;
        if (action == ACTION_SEND) startSending();
        else if (action == ACTION_RECEIVE) startReceiving();
    }

    // ---------------------------------------------------------- Nearby

    private void startReceiving() {
        resetNearby();
        AdvertisingOptions opts = new AdvertisingOptions.Builder()
                .setStrategy(Strategy.P2P_POINT_TO_POINT).build();
        client.startAdvertising(Build.MODEL, SERVICE_ID, connectionCallback, opts)
                .addOnSuccessListener(v -> {
                    setStatus("Receive mode: doosre phone par Send dabayein.\n"
                            + "Aapka phone: " + Build.MODEL);
                    roleRow.setVisibility(View.GONE);
                    disconnectBtn.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> setStatus("Shuru nahi hua: " + e.getMessage()
                        + "\n(Bluetooth aur Location on karein)"));
    }

    private void startSending() {
        resetNearby();
        foundIds.clear();
        foundNames.clear();
        deviceAdapter.notifyDataSetChanged();
        DiscoveryOptions opts = new DiscoveryOptions.Builder()
                .setStrategy(Strategy.P2P_POINT_TO_POINT).build();
        client.startDiscovery(SERVICE_ID, discoveryCallback, opts)
                .addOnSuccessListener(v -> {
                    setStatus("Doosre phone ko dhoond raha hai... (wahan Receive dabayein)\n"
                            + "Naam aane par us par tap karein.");
                    roleRow.setVisibility(View.GONE);
                    deviceList.setVisibility(View.VISIBLE);
                    disconnectBtn.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e -> setStatus("Shuru nahi hua: " + e.getMessage()
                        + "\n(Bluetooth aur Location on karein)"));
    }

    private final EndpointDiscoveryCallback discoveryCallback = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String id, DiscoveredEndpointInfo info) {
            if (!foundIds.contains(id)) {
                foundIds.add(id);
                foundNames.add(info.getEndpointName());
                deviceAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onEndpointLost(String id) {
            int i = foundIds.indexOf(id);
            if (i >= 0) {
                foundIds.remove(i);
                foundNames.remove(i);
                deviceAdapter.notifyDataSetChanged();
            }
        }
    };

    private final ConnectionLifecycleCallback connectionCallback = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String id, ConnectionInfo info) {
            // Dono taraf se khud accept (sirf nazdeek wale phones ke liye)
            setStatus("Connect ho raha hai: " + info.getEndpointName());
            client.acceptConnection(id, payloadCallback);
        }

        @Override
        public void onConnectionResult(String id, ConnectionResolution result) {
            if (result.getStatus().getStatusCode() == ConnectionsStatusCodes.STATUS_OK) {
                endpointId = id;
                connected = true;
                client.stopAdvertising();
                client.stopDiscovery();
                deviceList.setVisibility(View.GONE);
                disconnectBtn.setVisibility(View.VISIBLE);
                roleRow.setVisibility(View.GONE);
                if (sendPanelShouldShow) {
                    sendPanel.setVisibility(View.VISIBLE);
                    setStatus("Connected! Ab bhejne ke liye files ya apps chunein.");
                } else {
                    setStatus("Connected! Files yahan aani shuru ho jayengi.\n"
                            + "Save hongi: Downloads/OfflineShare");
                }
                log("Connected.");
            } else {
                setStatus("Connection nahi bana. Dobara koshish karein.");
            }
        }

        @Override
        public void onDisconnected(String id) {
            if (connected) {
                resetAll("Doosre phone se connection toot gaya.");
            }
        }
    };

    // sender hai ya receiver, ye connect hone par pata hona chahiye
    private boolean sendPanelShouldShow = false;

    private void resetNearby() {
        client.stopAllEndpoints();
        client.stopAdvertising();
        client.stopDiscovery();
        connected = false;
        endpointId = null;
        sendPanelShouldShow = (lastRole == ACTION_SEND);
    }

    private int lastRole = ACTION_NONE;

    private void resetAll(String message) {
        client.stopAllEndpoints();
        client.stopAdvertising();
        client.stopDiscovery();
        connected = false;
        endpointId = null;
        sendPanelShouldShow = false;
        lastRole = ACTION_NONE;
        filePayloads.clear();
        incomingNames.clear();
        finished.clear();
        saved.clear();
        outgoingNames.clear();
        runOnUiThread(() -> {
            roleRow.setVisibility(View.VISIBLE);
            deviceList.setVisibility(View.GONE);
            sendPanel.setVisibility(View.GONE);
            disconnectBtn.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            progressLabel.setText("");
        });
        setStatus(message);
    }

    // ----------------------------------------------------------- Send

    private void pickFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int k = 0; k < data.getClipData().getItemCount(); k++) {
                uris.add(data.getClipData().getItemAt(k).getUri());
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        for (Uri u : uris) {
            sendUri(u);
        }
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (name == null) name = "file_" + System.currentTimeMillis();
        return name;
    }

    private void sendUri(Uri uri) {
        if (!connected || endpointId == null) {
            setStatus("Pehle doosre phone se connect karein.");
            return;
        }
        try {
            String name = queryName(uri);
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) throw new FileNotFoundException();
            queuePayload(Payload.fromFile(pfd), name);
        } catch (Exception e) {
            log("Bhej nahi saka: " + e.getMessage());
        }
    }

    private void queuePayload(Payload filePayload, String name) {
        // Pehle naam bhejte hain, phir file
        String header = "NAME:" + filePayload.getId() + ":" + name;
        client.sendPayload(endpointId, Payload.fromBytes(header.getBytes(StandardCharsets.UTF_8)));
        client.sendPayload(endpointId, filePayload);
        outgoingNames.put(filePayload.getId(), name);
        log("Bhej raha hai: " + name);
    }

    private void pickApps() {
        if (!connected) {
            setStatus("Pehle doosre phone se connect karein.");
            return;
        }
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);

        final List<ApplicationInfo> apps = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        List<String[]> temp = new ArrayList<>();
        for (ResolveInfo ri : list) {
            ApplicationInfo ai = ri.activityInfo.applicationInfo;
            if (ai.packageName.equals(getPackageName())) continue;
            if (!seen.add(ai.packageName)) continue;
            boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            if (isSystem) continue;
            apps.add(ai);
            temp.add(new String[]{String.valueOf(pm.getApplicationLabel(ai)), ai.packageName});
        }
        // naam ke hisab se sort
        final List<Integer> order = new ArrayList<>();
        for (int i = 0; i < apps.size(); i++) order.add(i);
        Collections.sort(order, (a, b) -> temp.get(a)[0].compareToIgnoreCase(temp.get(b)[0]));
        final List<ApplicationInfo> sortedApps = new ArrayList<>();
        for (int idx : order) {
            sortedApps.add(apps.get(idx));
            labels.add(temp.get(idx)[0]);
        }

        if (sortedApps.isEmpty()) {
            setStatus("Koi installed app nahi mili.");
            return;
        }

        final boolean[] checked = new boolean[sortedApps.size()];
        new AlertDialog.Builder(this)
                .setTitle("Apps chunein")
                .setMultiChoiceItems(labels.toArray(new String[0]), checked,
                        (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Bhejein", (d, w) -> {
                    for (int i = 0; i < checked.length; i++) {
                        if (!checked[i]) continue;
                        ApplicationInfo ai = sortedApps.get(i);
                        try {
                            File apk = new File(ai.sourceDir);
                            queuePayload(Payload.fromFile(apk), labels.get(i) + ".apk");
                        } catch (FileNotFoundException e) {
                            log("App nahi bheji ja saki: " + labels.get(i));
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // -------------------------------------------------------- Receive

    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String id, Payload payload) {
            if (payload.getType() == Payload.Type.BYTES) {
                byte[] b = payload.asBytes();
                if (b == null) return;
                String s = new String(b, StandardCharsets.UTF_8);
                if (s.startsWith("NAME:")) {
                    int colon = s.indexOf(':', 5);
                    if (colon > 5) {
                        try {
                            long pid = Long.parseLong(s.substring(5, colon));
                            incomingNames.put(pid, s.substring(colon + 1));
                            tryFinish(pid);
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            } else if (payload.getType() == Payload.Type.FILE) {
                filePayloads.put(payload.getId(), payload);
            }
        }

        @Override
        public void onPayloadTransferUpdate(String id, PayloadTransferUpdate u) {
            long pid = u.getPayloadId();
            boolean isFile = filePayloads.containsKey(pid) || outgoingNames.containsKey(pid);
            switch (u.getStatus()) {
                case PayloadTransferUpdate.Status.IN_PROGRESS:
                    if (isFile && u.getTotalBytes() > 0) {
                        String n = outgoingNames.containsKey(pid)
                                ? "Bhej raha hai: " + outgoingNames.get(pid)
                                : "Wasool ho raha hai: " + (incomingNames.containsKey(pid)
                                ? incomingNames.get(pid) : "file");
                        showProgress(n, u.getBytesTransferred(), u.getTotalBytes());
                    }
                    break;
                case PayloadTransferUpdate.Status.SUCCESS:
                    if (outgoingNames.containsKey(pid)) {
                        log("Bhej di gayi: " + outgoingNames.get(pid));
                        hideProgress();
                    } else if (filePayloads.containsKey(pid)) {
                        finished.add(pid);
                        tryFinish(pid);
                    }
                    break;
                case PayloadTransferUpdate.Status.FAILURE:
                case PayloadTransferUpdate.Status.CANCELED:
                    if (isFile) {
                        log("Transfer fail ho gaya. Dobara bhejein.");
                        hideProgress();
                    }
                    break;
                default:
                    break;
            }
        }
    };

    private void showProgress(String label, long done, long total) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress((int) (done * 1000L / total));
            progressLabel.setText(label + "  (" + (done * 100L / total) + "%)");
        });
    }

    private void hideProgress() {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            progressLabel.setText("");
        });
    }

    private void tryFinish(long pid) {
        if (saved.contains(pid)) return;
        if (!(filePayloads.containsKey(pid) && incomingNames.containsKey(pid)
                && finished.contains(pid))) return;
        saved.add(pid);
        final Payload payload = filePayloads.get(pid);
        final String name = sanitize(incomingNames.get(pid));
        hideProgress();
        io.execute(() -> {
            try {
                Payload.File pf = payload.asFile();
                if (pf == null) throw new FileNotFoundException("file nahi mili");
                saveToDownloads(pf.asParcelFileDescriptor(), name);
                log("Save ho gayi: Downloads/OfflineShare/" + name);
            } catch (Exception e) {
                log("Save nahi hui (" + name + "): " + e.getMessage());
            }
        });
    }

    private String sanitize(String n) {
        if (n == null || n.trim().isEmpty()) return "file_" + System.currentTimeMillis();
        return n.replace('/', '_').replace('\\', '_').replace(':', '_');
    }

    private void saveToDownloads(ParcelFileDescriptor src, String name) throws Exception {
        try (InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(src)) {
            OutputStream out;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/OfflineShare");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new FileNotFoundException("Downloads mein file nahi bani");
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "OfflineShare");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                out = new FileOutputStream(new File(dir, name));
            }
            if (out == null) throw new FileNotFoundException("output nahi khula");
            try (OutputStream o = out) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    o.write(buf, 0, n);
                }
            }
        }
    }

    // ------------------------------------------------------- Lifecycle

    @Override
    protected void onDestroy() {
        client.stopAllEndpoints();
        client.stopAdvertising();
        client.stopDiscovery();
        io.shutdown();
        super.onDestroy();
    }
}
